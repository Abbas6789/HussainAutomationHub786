# ⚡ Hussain Automation Hub 786

**Dual-app Social Media Automation Platform**
Upload once → post to YouTube Shorts, Facebook Reels & TikTok simultaneously with AI-generated metadata.

---

## 📁 Project Structure

```
HussainAutomationHub786/
├── app.py                        ← PUBLIC USER PORTAL  (URL 1)
├── admin.py                      ← PRIVATE ADMIN PANEL (URL 2)
├── requirements.txt
├── .gitignore
├── assets/
│   └── background.jpg            ← Your profile photo (faded background)
├── shared/
│   ├── firebase_utils.py         ← Firestore helpers
│   ├── styles.py                 ← CSS, background, brand header
│   ├── ai_meta.py                ← AI title/hashtag generation
│   └── uploaders.py              ← YouTube/Facebook/TikTok upload logic
└── .streamlit/
    ├── config.toml               ← Dark theme config
    └── secrets.toml.example      ← Copy → secrets.toml (never commit)
```

---

## 🚀 Deployment Guide (Two Separate Streamlit Cloud URLs)

### Step 1 — Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit - Hussain Automation Hub"
git remote add origin https://github.com/YOUR_USERNAME/HussainAutomationHub786.git
git push -u origin main
```

### Step 2 — Deploy Public App (URL 1)

1. Go to [share.streamlit.io](https://share.streamlit.io)
2. Click **New App**
3. Select your repo: `HussainAutomationHub786`
4. **Main file path:** `app.py`
5. Click **Deploy** → You get: `https://YOUR-USERNAME-hussainautomationhub786-app-XXXX.streamlit.app`

### Step 3 — Deploy Admin Panel (URL 2)

1. Click **New App** again (same repo)
2. **Main file path:** `admin.py`
3. Click **Deploy** → You get: `https://YOUR-USERNAME-hussainautomationhub786-admin-XXXX.streamlit.app`
4. **Keep this URL private** — share only with yourself.

### Step 4 — Add Secrets to BOTH apps

In Streamlit Cloud → App Settings → **Secrets**, paste:

```toml
FIREBASE_CREDENTIALS = '{"type":"service_account","project_id":"YOUR_PROJECT_ID",...}'
```

---

## 🔥 Firebase Setup (One-Time)

1. Go to [console.firebase.google.com](https://console.firebase.google.com)
2. Click **Add project** → name it `hussain-automation-hub`
3. Once created → **Project Settings** → **Service Accounts**
4. Click **Generate new private key** → download JSON file
5. **Option A (Streamlit Cloud):** Paste the entire JSON content as one line into Secrets as `FIREBASE_CREDENTIALS`
6. **Option B (Local):** Rename the file to `firebase_credentials.json` and place it in the project root

### Create Firestore Database
1. In Firebase Console → **Firestore Database** → **Create database**
2. Choose **Start in test mode** (update rules before going live)
3. Select your region (e.g., `us-central1`)

---

## 🔑 Admin Login

| Field    | Value       |
|----------|-------------|
| Username | `ashkeel`   |
| Password | Your existing password |

> To change the password: run `python3 -c "import hashlib; print(hashlib.sha256(('hussain_hub_salt_786'+'NEWPASSWORD').encode()).hexdigest())"` and update `ADMIN_PW_HASH` in `admin.py`.

---

## 📱 WhatsApp Support Button

In `shared/styles.py`, update this line with your real WhatsApp number:

```python
WHATSAPP_NUMBER = "923001234567"  # e.g., 923331234567 (no + sign, no spaces)
```

---

## 🤖 AI Metadata (Auto Title + Hashtags)

The app uses the **Anthropic Claude API** to auto-generate titles and hashtags.

1. Get your API key from [console.anthropic.com](https://console.anthropic.com)
2. Add it in the Admin Panel → **⚙️ API Keys** → Anthropic API Key
   OR add to Streamlit Secrets: `ANTHROPIC_API_KEY = "sk-ant-..."`

If no key is provided, the app uses smart template-based fallback generation automatically.

---

## 🔐 Security Notes

- **Never commit** `firebase_credentials.json` or `secrets.toml` to GitHub (both are in `.gitignore`)
- Your Google OAuth Client ID (`249087096220-...`) was shared publicly — **rotate it** at [console.cloud.google.com](https://console.cloud.google.com) after deployment
- Your password was shared publicly — **change it immediately** on all accounts where it was used

---

## ✅ Feature Checklist

| Feature | Status |
|---|---|
| Dual apps (2 separate URLs) | ✅ |
| Admin login (ashkeel / hashed password) | ✅ |
| Faded profile photo background | ✅ |
| Google OAuth login | ✅ |
| WhatsApp support button (pre & post login) | ✅ |
| Firebase Firestore real-time sync | ✅ |
| Device/user approval system | ✅ |
| Live balance display | ✅ |
| AI-generated titles + hashtags | ✅ |
| One-click post to all 3 platforms | ✅ |
| Platform enable/disable toggles | ✅ |
| API key management in admin | ✅ |
| System message editor | ✅ |
| Force refresh button | ✅ |
| User balance management | ✅ |
| Audit log | ✅ |
